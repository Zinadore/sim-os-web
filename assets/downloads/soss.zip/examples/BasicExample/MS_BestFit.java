// We MUST be in the soss.managers package
package soss.managers;

// Import the core package
import soss.core.*;


import java.util.*;


public class MS_BestFit extends DefaultMemoryManager{
 
  public MS_BestFit(int RAMsize){
    super(RAMsize);
    
  }  
  
  public int findAvailablePartition(int size){
    // Do my best fir magic to find a partition 'size' big
    return -1; 
  }
  
  public String toString(){
    return "Best Fit";
  }
}
