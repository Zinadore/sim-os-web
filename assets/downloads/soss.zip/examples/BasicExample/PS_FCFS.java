// We MUST be in the soss.schedulers package
package soss.schedulers;

// Import the soss.core.Process class since we use it.
import soss.core.Process;

import java.util.*;


public class PS_FCFS extends DefaultProcessScheduler {
  
  public PS_FCFS(){
    super();
  }

  public Process selectProcessToRun(){
    
    Process p = null;
    // Figure out which process to run
    return p;
  }

  public boolean preempt() {
    return false;
  }
  
  public void removeProcess(Process p) {
    // Remove p from the queue
    // Remember we are inheriting a protected
    // variable called queue!
    // Maybe this is a good time to do some
    // additional bookkeeping?
  }

  public void addProcess(Process p) {
    // Add p to the queue
    // Remember we are inheriting a protected
    // variable called queue!
    // Maybe this is a good time to do some
    // additional bookkeeping?
  }

  public String toString(){
    return "First Come First Served";
  }
}
